# Music files

The playlist currently includes these MP3 files:

- `jeena_jeena.mp3` - Jeena Jeena
- `oh_oh_jane_jaana.mp3` - Oh Oh Jane Jaana
- `o_re_piya.mp3` - O Re Piya

The song paths and the displayed playlist titles are set in the
`MUSIC_TRACK_PATHS` and `MUSIC_TRACK_NAMES` arrays near the top of `main.cpp`.
SFML also supports WAV, OGG/Vorbis, and FLAC files.
